
import { _decorator, Component, Node, UITransform, Size, math } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('ProgressbarMaskController')
export class ProgressbarMaskController extends Component {
    @property(UITransform)
    maskUITransform: UITransform

    maxContentSize: Size = new Size()
    targetContentSize: Size = new Size()
    currentContentSize: Size = new Size()

    onLoad() {
        this.maxContentSize.set(this.maskUITransform.contentSize)
        this.targetContentSize.set(this.maskUITransform.contentSize)
        this.targetContentSize.width = 0
        this.currentContentSize.set(this.targetContentSize)
        this.updateContentSize()
    }

    setProgress(progress: number) {
        progress = math.clamp(progress, 0.0, 1.0)
        this.targetContentSize.width = progress * this.maxContentSize.x

        this.currentContentSize.set(this.targetContentSize)
        this.updateContentSize();
    }

    updateContentSize() {
        this.maskUITransform.setContentSize(this.currentContentSize.width, this.currentContentSize.height)
    }
}