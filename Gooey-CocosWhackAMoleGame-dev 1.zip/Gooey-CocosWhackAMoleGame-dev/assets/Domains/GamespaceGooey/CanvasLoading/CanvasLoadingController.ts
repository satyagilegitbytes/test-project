
import { _decorator, Component, Node } from 'cc';
import { LabelLoadingTaskController } from './LabelLoadingTaskController';
import { ProgressbarMaskController } from './ProgressbarMaskController';
const { ccclass, property } = _decorator;

@ccclass('CanvasLoadingController')
export class CanvasLoadingController extends Component {

    @property(ProgressbarMaskController)
    progressbarMaskController: ProgressbarMaskController

    @property(LabelLoadingTaskController)
    labelLoadingTaskController: LabelLoadingTaskController

    show() {
        this.node.active = true
    }

    hide() {
        this.node.active = false
    }

    setProgress(progress: number, taskName: string) {
        this.labelLoadingTaskController.setText(taskName)
        this.progressbarMaskController.setProgress(progress)
    }
}