
import { _decorator, Component, Node, Camera } from 'cc';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = MainCamera
 * DateTime = Tue Oct 05 2021 10:40:18 GMT+0700 (Indochina Time)
 * Author = noptanakhon
 * FileBasename = MainCamera.ts
 * FileBasenameNoExtension = MainCamera
 * URL = db://assets/GooeyGames/MainCamera.ts
 * ManualUrl = https://docs.cocos.com/creator/3.3/manual/en/
 *
 */

@ccclass('MainCamera')
export class MainCamera extends Component {

    @property(Camera)
    private camera: Camera

    static Camera: Camera

    onLoad() {
        MainCamera.Camera = this.camera;
    }
}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.3/manual/en/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.3/manual/en/scripting/ccclass.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.3/manual/en/scripting/life-cycle-callbacks.html
 */
