
import { _decorator, Component, Node, NodePool, instantiate, Prefab } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('PoolManager')
export class PoolManager extends Component {

    @property(Prefab)
    private prefab: Prefab

    private nodePool: NodePool
    onEnable() {
        this.nodePool = new NodePool()
    }

    public Spawn(parentNode: Node): Node {
        if (this.nodePool.size() <= 0) { // use size method to check if there're nodes available in the pool
            const bullet = instantiate(this.prefab);
            this.nodePool.put(bullet);
        }

        const bullet = this.nodePool.get();
        bullet.parent = parentNode; // add new enemy node to the node tree
        return bullet
    }

    public Despawn(node: Node) {
        this.nodePool.put(node);
    }

    size(): number {
        return this.nodePool.size()
    }
}