import { math } from "cc"


export default function (from?: math.Vec3, to?: math.Vec3, step?: number) {
  const direction = to.subtract(from).normalize()
  from.x += direction.x * step
  from.y += direction.y * step
  from.z += direction.z * step
}