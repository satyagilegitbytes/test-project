
import { _decorator, Component, Node, assetManager } from 'cc';
import { GooeyRemoteAssetBase } from '../Components/GooeyRemoteAssetBase';
const { ccclass, property } = _decorator;


export default function (remoteAsset: GooeyRemoteAssetBase, callback) {
    const url = remoteAsset.url.toString()
    assetManager.loadRemote(url, function (err, asset) {
        if (err) {
            callback(err)
        } else {
            remoteAsset.setAsset(asset)
            callback(null)
        }
    });
}

