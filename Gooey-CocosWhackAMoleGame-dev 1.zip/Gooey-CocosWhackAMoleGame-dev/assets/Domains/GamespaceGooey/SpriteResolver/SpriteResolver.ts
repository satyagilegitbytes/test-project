
import { _decorator, Component, Node, Sprite, SpriteFrame } from 'cc';
import { SpriteFrameLibrary } from './SpriteFrameLibrary';
const { ccclass, property } = _decorator;
/**
 * Predefined variables
 * Name = SpriteResolver
 * DateTime = Wed Oct 06 2021 14:45:38 GMT+0700 (Indochina Time)
 * Author = noptanakhon
 * FileBasename = SpriteResolver.ts
 * FileBasenameNoExtension = SpriteResolver
 * URL = db://assets/GamespaceGooey/SpriteResolver/SpriteResolver.ts
 * ManualUrl = https://docs.cocos.com/creator/3.3/manual/en/
 *
 */


@ccclass('SpriteResolver')
export class SpriteResolver extends Component {

    @property(Sprite)
    sprite: Sprite

    @property(SpriteFrameLibrary)
    spriteFrameLibrary: SpriteFrameLibrary

    public setSpriteFrameByIndex(index: number) {
        const spriteFrame = this.spriteFrameLibrary.getSpriteFrameByIndex(index)
        if (spriteFrame) {
            this.sprite.spriteFrame = spriteFrame
        }
    }
}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.3/manual/en/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.3/manual/en/scripting/ccclass.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.3/manual/en/scripting/life-cycle-callbacks.html
 */
