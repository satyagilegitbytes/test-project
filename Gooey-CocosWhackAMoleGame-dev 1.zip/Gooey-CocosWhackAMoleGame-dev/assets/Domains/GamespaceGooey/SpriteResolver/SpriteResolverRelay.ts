
import { _decorator, Component, Node } from 'cc';
import { SpriteResolver } from './SpriteResolver';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = SpriteResolverRelay
 * DateTime = Fri Oct 08 2021 09:04:10 GMT+0700 (Indochina Time)
 * Author = noptanakhon
 * FileBasename = SpriteResolverRelay.ts
 * FileBasenameNoExtension = SpriteResolverRelay
 * URL = db://assets/GamespaceGooey/SpriteResolver/SpriteResolverRelay.ts
 * ManualUrl = https://docs.cocos.com/creator/3.3/manual/en/
 *
 */

@ccclass('SpriteResolverRelay')
export class SpriteResolverRelay extends Component {

    @property(SpriteResolver)
    spriteResolvers: SpriteResolver[] = []

    public setSpriteFrameByIndex(index: number) {
        for (let i = 0; i < this.spriteResolvers.length; i++) {
            this.spriteResolvers[i].setSpriteFrameByIndex(index)
        }
    }
}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.3/manual/en/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.3/manual/en/scripting/ccclass.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.3/manual/en/scripting/life-cycle-callbacks.html
 */
