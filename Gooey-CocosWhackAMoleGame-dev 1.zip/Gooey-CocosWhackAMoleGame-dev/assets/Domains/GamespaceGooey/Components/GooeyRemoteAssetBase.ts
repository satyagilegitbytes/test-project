
import { _decorator, Component, Node, SpriteFrame, CCString, Asset } from 'cc';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = GooeySprite
 * DateTime = Tue Oct 12 2021 09:27:56 GMT+0700 (Indochina Time)
 * Author = noptanakhon
 * FileBasename = GooeySprite.ts
 * FileBasenameNoExtension = GooeySprite
 * URL = db://assets/GamespaceGooey/Components/GooeySprite.ts
 * ManualUrl = https://docs.cocos.com/creator/3.3/manual/en/
 *
 */

export interface GooeyRemoteAssetBase {
    url: String
    setAsset(asset: Asset)
}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.3/manual/en/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.3/manual/en/scripting/ccclass.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.3/manual/en/scripting/life-cycle-callbacks.html
 */
