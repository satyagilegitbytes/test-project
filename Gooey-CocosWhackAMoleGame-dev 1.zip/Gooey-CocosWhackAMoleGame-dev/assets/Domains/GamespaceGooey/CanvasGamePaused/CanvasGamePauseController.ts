
import { _decorator, Component, Node, director } from 'cc';
const { ccclass, property } = _decorator;


@ccclass('CanvasGamePauseController')
export class CanvasGamePauseController extends Component {

    open() {
        this.node.active = true
        director.pause()
    }

    close() {
        this.node.active = false
        director.resume()
    }

}
