
import { _decorator, Component, Node, Vec3 } from 'cc';
import { ActionNodeBase } from './ActionNodeBase';
const { ccclass, property } = _decorator;

@ccclass('ActionNodePositionSet')
export class ActionNodePositionSet extends ActionNodeBase {

    @property(Vec3)
    position: Vec3 = new Vec3()

    _ActionBase_Start() {
        this.workingNode.setPosition(this.position)
        this._ActionBase_End()
    }
}