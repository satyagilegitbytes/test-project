
import { _decorator, Component, Node, Vec3, CCString, tween, CCFloat, TweenEasing } from 'cc';
import { ActionNodeBase } from './ActionNodeBase';
const { ccclass, property } = _decorator;


@ccclass('ActionNodePositionMove')
export class ActionNodePositionMove extends ActionNodeBase {
    @property(Vec3)
    position: Vec3 = new Vec3()

    @property(CCFloat)
    duration: number = 0.5

    @property(CCString)
    easing: TweenEasing = "smooth"

    _ActionBase_Start() {
        const self = this
        // this.node.position.set(this.position)
        tween(this.workingNode).to(this.duration, { position: this.position }, {
            easing: this.easing, onComplete: function () {
                self._ActionBase_End()
            }
        }).start()
    }
}
