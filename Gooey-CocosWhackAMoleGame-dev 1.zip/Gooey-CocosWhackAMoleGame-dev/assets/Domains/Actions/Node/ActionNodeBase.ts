
import { _decorator, Component, Node } from 'cc';
import { ActionStartEndBase } from '../Base/ActionStartEndBase';
const { ccclass, property } = _decorator;

@ccclass('ActionNodeBase')
export abstract class ActionNodeBase extends ActionStartEndBase {
    @property(Node)
    workingNode: Node
}
