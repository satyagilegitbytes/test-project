
import { _decorator, Component, Node, UIOpacity } from 'cc';
import { ActionStartEndBase } from '../Base/ActionStartEndBase';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = ActionUIOpacityBase
 * DateTime = Wed Oct 20 2021 09:42:04 GMT+0700 (Indochina Time)
 * Author = noptanakhon
 * FileBasename = ActionUIOpacityBase.ts
 * FileBasenameNoExtension = ActionUIOpacityBase
 * URL = db://assets/Domains/Actions/UIOpacity/ActionUIOpacityBase.ts
 * ManualUrl = https://docs.cocos.com/creator/3.3/manual/en/
 *
 */

@ccclass('ActionUIOpacityBase')
export abstract class ActionUIOpacityBase extends ActionStartEndBase {
    @property(UIOpacity)
    uiOpacity: UIOpacity
}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.3/manual/en/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.3/manual/en/scripting/ccclass.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.3/manual/en/scripting/life-cycle-callbacks.html
 */
