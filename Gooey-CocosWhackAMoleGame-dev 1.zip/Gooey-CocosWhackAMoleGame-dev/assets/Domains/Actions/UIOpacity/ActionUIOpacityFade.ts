
import { _decorator, Component, Node, CCInteger, tween, CCFloat } from 'cc';
import { ActionUIOpacityBase } from './ActionUIOpacityBase';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = ActionUIOpacityFade
 * DateTime = Wed Oct 20 2021 09:41:45 GMT+0700 (Indochina Time)
 * Author = noptanakhon
 * FileBasename = ActionUIOpacityFade.ts
 * FileBasenameNoExtension = ActionUIOpacityFade
 * URL = db://assets/Domains/Actions/UIOpacity/ActionUIOpacityFade.ts
 * ManualUrl = https://docs.cocos.com/creator/3.3/manual/en/
 *
 */

@ccclass('ActionUIOpacityFade')
export class ActionUIOpacityFade extends ActionUIOpacityBase {

    @property(CCInteger)
    targetPpacity: Number = 255

    @property(CCFloat)
    duration: Number = 0.5

    _ActionBase_Start() {

        const self = this
        tween(this.uiOpacity).to(this.duration.valueOf(), { opacity: this.targetPpacity.valueOf() }, {
            easing: "sineIn", onComplete: function () {
                self._ActionBase_End()
            }
        }).start()
    }
}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.3/manual/en/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.3/manual/en/scripting/ccclass.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.3/manual/en/scripting/life-cycle-callbacks.html
 */
