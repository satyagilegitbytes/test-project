
import { _decorator, Component, Node, UIOpacity, CCFloat, CCInteger } from 'cc';
import { ActionStartEndBase } from '../Base/ActionStartEndBase';
import { ActionUIOpacityBase } from './ActionUIOpacityBase';
const { ccclass, property } = _decorator;

@ccclass('ActionUIOpacitySet')
export class ActionUIOpacitySet extends ActionUIOpacityBase {

    @property(CCInteger)
    opacity: Number = 0

    _ActionBase_Start() {
        this.uiOpacity.opacity = this.opacity.valueOf()
        this._ActionBase_End()
    }

}