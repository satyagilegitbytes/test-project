
import { _decorator, Component, Node, CCString, director } from 'cc';
import { ActionStartEndBase } from '../Base/ActionStartEndBase';
const { ccclass, property } = _decorator;

@ccclass('ActionSceneChange')
export class ActionSceneChange extends ActionStartEndBase {
    // [1]
    // dummy = '';

    @property(CCString)
    sceneName: string = ""

    _ActionBase_Start() {
        director.loadScene(this.sceneName)
        super._ActionBase_End()
    }
}