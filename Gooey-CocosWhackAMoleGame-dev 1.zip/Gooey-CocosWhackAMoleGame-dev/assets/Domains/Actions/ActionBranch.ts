
import { _decorator, Component, Node } from 'cc';
import { ActionStartBase } from './Base/ActionStartBase';
import { ActionStartEndBase } from './Base/ActionStartEndBase';
const { ccclass, property } = _decorator;

@ccclass('ActionBranch')
export class ActionBranch extends ActionStartEndBase {

    @property(ActionStartBase)
    branchAction: ActionStartBase

    _ActionBase_Start() {
        this.branchAction._ActionBase_Start()
        this._ActionBase_End()
    }

}