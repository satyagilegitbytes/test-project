
import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = IActionStart
 * DateTime = Fri Oct 15 2021 09:16:28 GMT+0700 (Indochina Time)
 * Author = noptanakhon
 * FileBasename = IActionStart.ts
 * FileBasenameNoExtension = IActionStart
 * URL = db://assets/Domains/Actions/Base/IActionStart.ts
 * ManualUrl = https://docs.cocos.com/creator/3.3/manual/en/
 *
 */

export default interface IActionStart {
    _ActionBase_Start();
}

