
import { _decorator, Component, Node } from 'cc';
import { ActionStartBase } from '../Base/ActionStartBase';
const { ccclass, property } = _decorator;

@ccclass('MonitorNodeEnable')
export class MonitorNodeEnable extends Component {
    @property(ActionStartBase)
    action: ActionStartBase

    onEnable() {
        this.action._ActionBase_Start()
    }
}
