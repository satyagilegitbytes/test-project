
import { _decorator, Component, Node } from 'cc';
import { PoolManager } from '../../Domains/GamespaceGooey/Tools/PoolManager';
import { SignalMoleScoreRequest } from '../Moles/MoleScoreRequestManager';
import { TextScoreFacade } from './Facade/TextScoreFacade';
const { ccclass, property } = _decorator;

export const SignalSpawnTextScore = "SignalSpawnTextScore"
@ccclass('TextScoreSpawnController')
export class TextScoreSpawnController extends Component {

    @property(Node)
    molesNode: Node

    @property(Node)
    textScoreParent: Node

    @property(PoolManager)
    poolManager: PoolManager

    onEnable() {
        this.molesNode.on(SignalMoleScoreRequest, this.spawnTextScore, this)
    }

    onDisable() {
        this.molesNode.off(SignalMoleScoreRequest, this.spawnTextScore, this)
    }

    spawnTextScore(moleNode: Node, score: number) {
        this.node.emit(SignalSpawnTextScore, score)
        
        const textScoreNode = this.poolManager.Spawn(this.textScoreParent)

        const textScoreFacade = textScoreNode.getComponent(TextScoreFacade)

        if (!textScoreFacade)
            return

        textScoreFacade.reset({ score: score, moleWorldPosition: moleNode.getWorldPosition() })
    }

}
