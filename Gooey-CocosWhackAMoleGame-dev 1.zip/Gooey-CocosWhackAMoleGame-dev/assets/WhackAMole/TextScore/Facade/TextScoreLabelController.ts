
import { _decorator, Component, Node, Label } from 'cc';
import { TextScoreSettings } from './TextScoreSettings';
import { SignalTextScoreSettingsDataUpdate } from './TextScoreSettingsDataManager';
const { ccclass, property } = _decorator;

@ccclass('TextScoreLabelController')
export class TextScoreLabelController extends Component {

    @property(Label)
    label: Label

    onEnable() {
        this.node.on(SignalTextScoreSettingsDataUpdate, this.signalTextScoreSettingsDataUpdate, this)
    }

    onDisable() {
        this.node.off(SignalTextScoreSettingsDataUpdate, this.signalTextScoreSettingsDataUpdate, this)
    }

    signalTextScoreSettingsDataUpdate(textScoreSettings: TextScoreSettings) {
        if (textScoreSettings.score >= 0) {
            this.label.string = "+" + textScoreSettings.score
        } else {
            this.label.string = "-" + textScoreSettings.score
        }
    }
}
