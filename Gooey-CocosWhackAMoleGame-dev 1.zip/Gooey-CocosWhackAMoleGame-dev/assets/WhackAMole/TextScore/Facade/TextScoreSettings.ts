
import { _decorator, Component, Node, Vec3 } from 'cc';
const { ccclass, property } = _decorator;

export class TextScoreSettings {
    score: number
    moleWorldPosition: Vec3
}