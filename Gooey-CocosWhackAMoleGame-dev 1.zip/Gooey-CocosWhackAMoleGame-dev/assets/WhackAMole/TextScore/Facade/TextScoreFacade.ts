
import { _decorator, Component, Node } from 'cc';
import { TextScoreSettings } from './TextScoreSettings';
import { TextScoreSettingsDataManager } from './TextScoreSettingsDataManager';
const { ccclass, property } = _decorator;

@ccclass('TextScoreFacade')
export class TextScoreFacade extends Component {

    @property(TextScoreSettingsDataManager)
    textScoreSettingsDataManager: TextScoreSettingsDataManager

    reset(textScoreSettings: TextScoreSettings) {
        this.node.setWorldPosition(textScoreSettings.moleWorldPosition)

        this.textScoreSettingsDataManager.setTextScoreSettings(textScoreSettings)
    }
}