
import { _decorator, Component, Node } from 'cc';
import { TextScoreSettings } from './TextScoreSettings';
const { ccclass, property } = _decorator;


export const SignalTextScoreSettingsDataUpdate = "SignalTextScoreSettingsDataUpdate"

@ccclass('TextScoreSettingsDataManager')
export class TextScoreSettingsDataManager extends Component {
    private textScoreSettings: TextScoreSettings

    setTextScoreSettings(textScoreSettings: TextScoreSettings) {
        this.textScoreSettings = textScoreSettings
        this.node.emit(SignalTextScoreSettingsDataUpdate, this.textScoreSettings)
    }
}

