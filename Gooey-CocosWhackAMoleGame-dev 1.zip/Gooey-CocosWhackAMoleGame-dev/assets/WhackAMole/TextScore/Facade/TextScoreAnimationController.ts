
import { _decorator, Component, Node, tween, Vec3, Event } from 'cc';
import { TextScoreSettings } from './TextScoreSettings';
import { SignalTextScoreSettingsDataUpdate } from './TextScoreSettingsDataManager';
const { ccclass, property } = _decorator;

export const SignalAnimationEnded = "SignalAnimationEnded"

@ccclass('TextScoreAnimationController')
export class TextScoreAnimationController extends Component {
    worldPosition1: Vec3 = new Vec3()
    worldPosition2: Vec3 = new Vec3()


    animationEndedEvent: AnimationEndedEvent
    onLoad() {
        this.animationEndedEvent = new AnimationEndedEvent(SignalAnimationEnded, true, this.node)
    }

    onEnable() {
        this.node.on(SignalTextScoreSettingsDataUpdate, this.signalTextScoreSettingsDataUpdate, this)
    }

    onDisable() {
        this.node.off(SignalTextScoreSettingsDataUpdate, this.signalTextScoreSettingsDataUpdate, this)
    }

    signalTextScoreSettingsDataUpdate(textScoreSettings: TextScoreSettings) {
        this.node.setScale(Vec3.ONE)
        this.node.setWorldPosition(textScoreSettings.moleWorldPosition)

        this.worldPosition1.set(textScoreSettings.moleWorldPosition)
        this.worldPosition1.y += 50

        this.worldPosition2.set(textScoreSettings.moleWorldPosition)
        this.worldPosition2.y += 55

        const self = this
        tween(this.node)
            .to(0.8, { worldPosition: this.worldPosition1 }, { easing: "smooth" })
            .to(0.5, { worldPosition: this.worldPosition2, scale: Vec3.ZERO }, {
                easing: "quadOut", onComplete: function () {
                    self.node.dispatchEvent(self.animationEndedEvent)
                }
            }).start()
    }
}

export class AnimationEndedEvent extends Event {
    constructor(name: any, bubbles?: boolean, detail?: Node) {
        super(name, bubbles);
        this.detail = detail;
    }
    public detail: Node = null;  // Custom property
}
