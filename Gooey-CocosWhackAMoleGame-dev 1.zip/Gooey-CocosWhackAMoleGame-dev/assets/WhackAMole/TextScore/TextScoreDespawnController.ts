
import { _decorator, Component, Node } from 'cc';
import { PoolManager } from '../../Domains/GamespaceGooey/Tools/PoolManager';
import { AnimationEndedEvent, SignalAnimationEnded } from './Facade/TextScoreAnimationController';
const { ccclass, property } = _decorator;

@ccclass('TextScoreDespawnController')
export class TextScoreDespawnController extends Component {

    @property(PoolManager)
    textScorePoolManager: PoolManager

    onEnable() {
        this.node.on(SignalAnimationEnded, this.signalAnimationEnded, this)
    }

    onDisable() {
        this.node.off(SignalAnimationEnded, this.signalAnimationEnded, this)
    }

    signalAnimationEnded(event: AnimationEndedEvent) {
        this.textScorePoolManager.Despawn(event.detail)
        event.propagationImmediateStopped = true
    }
}
