
import { _decorator, Component, Node } from 'cc';
import { MoleHoleFacade } from './Facade/MoleHoleFacade';
const { ccclass, property } = _decorator;


@ccclass('MoleHolesHolder')
export class MoleHolesHolder extends Component {

    // [2]
    @property([MoleHoleFacade])
    moleHoles: MoleHoleFacade[] = []

    getMoleHoles(): MoleHoleFacade[] {
        return this.moleHoles
    }
}
