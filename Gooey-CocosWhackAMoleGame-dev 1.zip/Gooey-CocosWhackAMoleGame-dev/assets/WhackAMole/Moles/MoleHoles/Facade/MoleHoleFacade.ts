
import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('MoleHoleFacade')
export class MoleHoleFacade extends Component {

    @property(Node)
    moleParent: Node

    getMoleParent(): Node {
        return this.moleParent
    }

    isAvailable(): boolean {
        for (let i = 0; i < this.moleParent.children.length; i++) {
            if (this.moleParent.children[i].active) {
                return false
            }
        }

        return true
    }
}