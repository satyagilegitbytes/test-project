
import { _decorator, Component, Node, Vec2, Vec3 } from 'cc';
import { MainCamera } from '../../Domains/GamespaceGooey/Tools/MainCamera';
import { SignalWhacked } from '../Whack/WhackInputManager';
import { MoleFacade } from './Facade/MoleFacade';
import { MolesHolder } from './MolesHolder';
const { ccclass, property } = _decorator;


@ccclass('MoleWhackManager')
export class MoleWhackManager extends Component {

    @property(Node)
    whackManagersNode: Node

    onEnable() {
        this.whackManagersNode.on(SignalWhacked, this.onWhacked, this)
    }

    onDisable() {
        this.whackManagersNode.off(SignalWhacked, this.onWhacked, this)
    }

    onWhacked(location: Vec2) {
        const worldPosition = this.getWorldPosition(location)
        const hitMole = this.findHitMole(worldPosition)

        if (hitMole) {
            //call hit moll
            hitMole.hitMole()
        }
    }

    getWorldPosition(location: Vec2): Vec3 {
        const location3d: Vec3 = new Vec3()
        location3d.x = location.x;
        location3d.y = location.y;
        location3d.z = 0

        return MainCamera.Camera.screenToWorld(location3d)
    }

    findHitMole(worldPosition: Vec3): MoleFacade {
        const moleFacades = MolesHolder.GetInstance().GetMoles()
        //check whack on mole
        for (let i = 0; i < moleFacades.length; i++) {
            const moleFacade = moleFacades[i]
            if (!moleFacade.isAlive()) {
                continue
            }
            
            const size = moleFacade.getUITransform().contentSize
            const widthHalf = size.width / 2
            const heightHalf = size.height / 2
            const moleWorldPosition = moleFacade.node.worldPosition

            if ((worldPosition.x >= moleWorldPosition.x - widthHalf && worldPosition.x <= moleWorldPosition.x + widthHalf) &&
                (worldPosition.y >= moleWorldPosition.y - heightHalf && worldPosition.y <= moleWorldPosition.y + heightHalf)) {
                return moleFacade
            }
        }
        return null
    }

}
