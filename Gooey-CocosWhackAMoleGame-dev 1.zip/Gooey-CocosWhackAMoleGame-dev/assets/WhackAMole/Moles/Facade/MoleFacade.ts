
import { _decorator, Component, Node, UITransform } from 'cc';
import { SpriteFrameLibrary } from '../../../Domains/GamespaceGooey/SpriteResolver/SpriteFrameLibrary';
import { MolesHolder } from '../MolesHolder';
import { MoleLiveManager } from './MoleLiveManager';
import { MoleSettings } from './MoleSettings';
import { MoleSettingsDataManager } from './MoleSettingsDataManager';
import { MoleUpDownAnimationController } from './MoleUpDownAnimationController';
const { ccclass, property } = _decorator;

@ccclass('MoleFacade')
export class MoleFacade extends Component {

    @property(UITransform)
    uiTransform: UITransform

    @property(MoleLiveManager)
    moleLiveManager: MoleLiveManager

    @property(SpriteFrameLibrary)
    moveUpSpriteFrameLibrary: SpriteFrameLibrary

    @property(MoleUpDownAnimationController)
    moleUpDownAnimationController: MoleUpDownAnimationController

    @property(MoleSettingsDataManager)
    moleSettingsDataManager: MoleSettingsDataManager
    
    onEnable() {
        MolesHolder.GetInstance().AddMole(this)
    }

    onDisable() {
        MolesHolder.GetInstance().RemoveMole(this)
    }

    reset(moleSettings: MoleSettings) {

        this.moveUpSpriteFrameLibrary.setSpriteFrames(moleSettings.moveUpSprites.getSpriteFrames())
        this.moleLiveManager.reset()
        this.moleUpDownAnimationController.reset()
        this.moleSettingsDataManager.setMoleSettingsData(moleSettings)
    }

    getUITransform(): UITransform {
        return this.uiTransform
    }

    hitMole() {
        this.moleLiveManager.kill()
    }

    isAlive(): boolean {
        return this.moleLiveManager.isAlive()
    }
}