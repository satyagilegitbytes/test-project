
import { _decorator, Component, Node, Event, Animation } from 'cc';
const { ccclass, property } = _decorator;


export const SignalMoleUpDownEnded = "SignalMoleUpDownEnded"
@ccclass('MoleUpDownAnimationController')
export class MoleUpDownAnimationController extends Component {

    @property(Animation)
    animation: Animation

    moleUpDownEndedEvent: MoleUpDownEndedEvent
    onLoad() {
        this.moleUpDownEndedEvent = new MoleUpDownEndedEvent(SignalMoleUpDownEnded, true, this.node)
    }

    reset() {
        this.animation.play("MoveUpAndDown")
    }

    //Call from animation
    endMoveUpAndDown() {
        this.node.dispatchEvent(this.moleUpDownEndedEvent)
    }
}

export class MoleUpDownEndedEvent extends Event {
    constructor(name: any, bubbles?: boolean, detail?: Node) {
        super(name, bubbles);
        this.detail = detail;
    }
    public detail: Node = null;  // Custom property
}
