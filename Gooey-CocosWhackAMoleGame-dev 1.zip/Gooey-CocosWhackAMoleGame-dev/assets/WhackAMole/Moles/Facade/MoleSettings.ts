
import { _decorator, Component, Node, Asset, CCString, SpriteFrame } from 'cc';
import { MoleData } from '../MoleData/MoleData';

const { ccclass, property } = _decorator;

export class MoleSettings extends MoleData {

}