
import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;


export const SignalMoleNotAlive = "SignalMoleNotAlive"
@ccclass('MoleLiveManager')
export class MoleLiveManager extends Component {

    alive: boolean = true
   
    reset() {
        this.alive = true
    }

    kill() {
        this.alive = false
        this.node.emit(SignalMoleNotAlive)
    }

    isAlive(): boolean {
        return this.alive
    }
}
