
import { _decorator, Component, Node } from 'cc';
import { MoleSettings } from './MoleSettings';
const { ccclass, property } = _decorator;

@ccclass('MoleSettingsDataManager')
export class MoleSettingsDataManager extends Component {
    // [1]
    // dummy = '';

    moleSettings: MoleSettings

    setMoleSettingsData(moleSettings: MoleSettings) {
        this.moleSettings = moleSettings
    }

    getMoleSettingsData(): MoleSettings {
        return this.moleSettings
    }

}
