
import { _decorator, Component, Node, Event } from 'cc';
import { SignalMoleNotAlive } from './MoleLiveManager';
import { MoleSettingsDataManager } from './MoleSettingsDataManager';
const { ccclass, property } = _decorator;

export const SignalMoleScored = "SignalMoleScored"
@ccclass('MoleScoringManager')
export class MoleScoringManager extends Component {

    @property(MoleSettingsDataManager)
    moleSettingsDataManager: MoleSettingsDataManager

    moleScoreEvent: MoleScoreEvent
    onLoad() {
        this.moleScoreEvent = new MoleScoreEvent(SignalMoleScored, true, this.node)
    }

    onEnable() {
        this.node.on(SignalMoleNotAlive, this.signalMoleNotAlive, this)
    }

    onDisable() {
        this.node.off(SignalMoleNotAlive, this.signalMoleNotAlive, this)
    }

    signalMoleNotAlive() {
        this.node.dispatchEvent(this.moleScoreEvent)
    }
}

export class MoleScoreEvent extends Event {
    constructor(name: any, bubbles?: boolean, detail?: Node) {
        super(name, bubbles);
        this.detail = detail;
    }
    public detail: Node = null;  // Custom property
}