
import { _decorator, Component, Node, Event, Animation } from 'cc';
import { SignalMoleNotAlive } from './MoleLiveManager';
const { ccclass, property } = _decorator;

export const SignalMoleWhackedEnded = "SignalMoleWhackedEnded"

@ccclass('MoleWhackedAnimationController')
export class MoleWhackedAnimationController extends Component {
    @property(Animation)
    animation: Animation

    moleWhackedEndedEvent: MoleWhackedEndedEvent
    onLoad() {
        this.moleWhackedEndedEvent = new MoleWhackedEndedEvent(SignalMoleWhackedEnded, true, this.node)
    }

    onEnable() {
        this.node.on(SignalMoleNotAlive, this.signalMoleNotAlive, this)
    }

    onDisable() {
        this.node.off(SignalMoleNotAlive, this.signalMoleNotAlive, this)
    }

    signalMoleNotAlive() {
        this.playWhackedAnimation()
    }

    playWhackedAnimation() {
        this.animation.play("Whacked")
    }

    endWhacked() {
        this.node.dispatchEvent(this.moleWhackedEndedEvent)
    }
}

export class MoleWhackedEndedEvent extends Event {
    constructor(name: any, bubbles?: boolean, detail?: Node) {
        super(name, bubbles);
        this.detail = detail;
    }
    public detail: Node = null;  // Custom property
}
