
import { _decorator, Component, Node } from 'cc';
import { MoleScoreEvent, SignalMoleScored } from './Facade/MoleScoringManager';
import { MoleSettingsDataManager } from './Facade/MoleSettingsDataManager';
const { ccclass, property } = _decorator;

export const SignalMoleScoreRequest = "SignalMoleScoreRequest"
@ccclass('MoleScoreRequestManager')
export class MoleScoreRequestManager extends Component {


    onEnable() {
        this.node.on(SignalMoleScored, this.signalMoleScored, this)
    }

    onDisable() {
        this.node.off(SignalMoleScored, this.signalMoleScored, this)
    }

    signalMoleScored(event: MoleScoreEvent) {
        const moleSettingManager = event.detail.getComponent(MoleSettingsDataManager)
        this.node.emit(SignalMoleScoreRequest, event.detail, moleSettingManager.getMoleSettingsData().score.valueOf())
        event.propagationImmediateStopped = true
    }
}