
import { _decorator, Component, Node } from 'cc';
import { MoleFacade } from './Facade/MoleFacade';
const { ccclass, property } = _decorator;

@ccclass('MolesHolder')
export class MolesHolder extends Component {
    private static _instance: MolesHolder

    public static GetInstance(): MolesHolder {
        return MolesHolder._instance
    }

    moles: MoleFacade[] = []

    onLoad() {
        MolesHolder._instance = this
    }

    GetMoles(): MoleFacade[] {
        return this.moles
    }

    AddMole(moleFacade: MoleFacade) {
        this.moles.push(moleFacade)
    }

    RemoveMole(moleFacade: MoleFacade) {
        var index = this.moles.indexOf(moleFacade);
        if (index !== -1) {
            this.moles.splice(index, 1);
        }
    }
}