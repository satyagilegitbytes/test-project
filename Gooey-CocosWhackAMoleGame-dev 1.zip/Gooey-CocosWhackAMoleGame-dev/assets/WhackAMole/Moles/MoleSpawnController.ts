
import { _decorator, Component, Node } from 'cc';
import { PoolManager } from '../../Domains/GamespaceGooey/Tools/PoolManager';
import { SignalTimerStarted } from '../Timer/TimerManager';
import { MoleDataManager } from './MoleDataManager';
import { MoleHolesHolder } from './MoleHoles/MoleHolesHolder';
import { MoleSpawner } from './MoleSpawner';
const { ccclass, property } = _decorator;


@ccclass('MoleSpawnController')
export class MoleSpawnController extends Component {

    @property(MoleDataManager)
    moleDataManager: MoleDataManager;

    @property(PoolManager)
    molePoolManager: PoolManager;

    @property(MoleHolesHolder)
    findAvailableMoleHole: MoleHolesHolder;

    moleSpawners: MoleSpawner[] = []

    @property(Node)
    timerNode: Node

    onEnable() {
        this.timerNode.on(SignalTimerStarted, this.signalTimerStarted, this)
    }

    onDisable() {
        this.timerNode.off(SignalTimerStarted, this.signalTimerStarted, this)
    }

    signalTimerStarted() {
        this.createMoleSpawners()
    }

    createMoleSpawners() {
        for (let i = 0; i < this.moleDataManager.moleDatas.length; i++) {
            const moleSpawner = new MoleSpawner(this.molePoolManager, this.moleDataManager.moleDatas[i], this.findAvailableMoleHole)
            moleSpawner.start()
            this.moleSpawners.push(moleSpawner)
        }
    }

    update(deltaTime: number) {
        for (let i = 0; i < this.moleSpawners.length; i++) {
            this.moleSpawners[i].update(deltaTime)
        }
    }
}