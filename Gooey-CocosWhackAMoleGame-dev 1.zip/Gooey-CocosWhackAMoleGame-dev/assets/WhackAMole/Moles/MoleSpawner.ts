
import { _decorator, Component, Node, randomRangeInt } from 'cc';
import { PoolManager } from '../../Domains/GamespaceGooey/Tools/PoolManager';
import { MoleFacade } from './Facade/MoleFacade';
import { MoleSettings } from './Facade/MoleSettings';
import { MoleData } from './MoleData/MoleData';
import { MoleHolesHolder } from './MoleHoles/MoleHolesHolder';
const { ccclass, property } = _decorator;

export class MoleSpawner {

    moleData: MoleData
    poolManager: PoolManager
    moldeHolesHolder: MoleHolesHolder

    nextSpawn: number
    counter: number

    constructor(poolManager: PoolManager, moleData: MoleData, moldeHolesHolder: MoleHolesHolder) {
        this.poolManager = poolManager
        this.moleData = moleData
        this.moldeHolesHolder = moldeHolesHolder
    }

    start() {
        this.counter = 0;
        this.randomNextSpawn()
    }

    update(delta: number) {
        this.counter += delta

        if (this.counter >= this.nextSpawn) {
            this.spawn()
            this.counter = 0
            this.randomNextSpawn()
        }
    }

    spawn() {
        const moleSettings: MoleSettings = this.moleData

        const moleParent = this.randomMoleParent()
        if (moleParent == null) {
            return
        }

        const moleNode = this.poolManager.Spawn(moleParent);
        const mole = moleNode.getComponent(MoleFacade)
        mole.reset(moleSettings)
    }

    randomNextSpawn() {
        const nextSpawnIndex = randomRangeInt(0, this.moleData.spawner.nextSpawn.length)
        this.nextSpawn = this.moleData.spawner.nextSpawn[nextSpawnIndex].valueOf()
    }

    randomMoleParent(): Node {
        const holes = this.moldeHolesHolder.getMoleHoles()

        const availableHoles: number[] = []
        for (let i = 0; i < holes.length; i++) {
            if (holes[i].isAvailable()) {
                availableHoles.push(i)
            }
        }

        if (availableHoles.length <= 0)
            return null

        const randomIndex = randomRangeInt(0, availableHoles.length)
        const holeIndex = availableHoles[randomIndex]
        return holes[holeIndex].getMoleParent()
    }
}
