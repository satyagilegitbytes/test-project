
import { _decorator, Component, Node } from 'cc';
import { MoleData } from './MoleData/MoleData';
const { ccclass, property } = _decorator;

@ccclass('MoleDataManager')
export class MoleDataManager extends Component {

    @property([MoleData])
    moleDatas: MoleData[] = []

    start() {
        // [3]
    }
}
