
import { _decorator, Component, Node } from 'cc';
import { PoolManager } from '../../Domains/GamespaceGooey/Tools/PoolManager';
import { MoleUpDownEndedEvent, SignalMoleUpDownEnded } from './Facade/MoleUpDownAnimationController';
import { MoleWhackedEndedEvent, SignalMoleWhackedEnded } from './Facade/MoleWhackedAnimationController';
const { ccclass, property } = _decorator;

@ccclass('MoleDespawnController')
export class MoleDespawnController extends Component {

    @property(PoolManager)
    molePoolManager: PoolManager

    onEnable() {
        this.node.on(SignalMoleUpDownEnded, this.signalMoleMovedToEnd, this)
        this.node.on(SignalMoleWhackedEnded, this.signalMoleWhackedToEnd, this)
    }

    onDisable() {
        this.node.off(SignalMoleUpDownEnded, this.signalMoleMovedToEnd, this)
        this.node.off(SignalMoleWhackedEnded, this.signalMoleWhackedToEnd, this)
    }

    signalMoleMovedToEnd(event: MoleUpDownEndedEvent) {
        this.molePoolManager.Despawn(event.detail)
        event.propagationImmediateStopped = true
    }

    signalMoleWhackedToEnd(event: MoleWhackedEndedEvent) {
        this.molePoolManager.Despawn(event.detail)
        event.propagationImmediateStopped = true
    }
}
