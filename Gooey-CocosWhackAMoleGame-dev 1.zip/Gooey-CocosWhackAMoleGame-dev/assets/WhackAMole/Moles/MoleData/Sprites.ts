
import { _decorator, Component, Node, Asset, CCFloat, SpriteFrame } from 'cc';
import { GooeySprite } from '../../../Domains/GamespaceGooey/Components/GooeySprite';
const { ccclass, property } = _decorator;

@ccclass('MoleSprites')
export class Sprites {

    spriteFrames: SpriteFrame[]
    getSpriteFrames(): SpriteFrame[] {
        if (!this.spriteFrames) {
            this.spriteFrames = []
            for (let i = 0; i < this.gooeySprites.length; i++) {
                this.spriteFrames.push(this.gooeySprites[i].spriteFrame)
            }
        }
        return this.spriteFrames
    }

    @property(GooeySprite)
    gooeySprites: GooeySprite[] = []
}