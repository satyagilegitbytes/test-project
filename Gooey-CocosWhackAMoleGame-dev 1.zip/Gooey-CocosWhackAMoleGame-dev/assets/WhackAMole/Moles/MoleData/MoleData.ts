
import { _decorator, Component, Node, Asset, CCString, CCInteger } from 'cc';
import { Spawner } from './Spawner';
import { Sprites } from './Sprites';

const { ccclass, property } = _decorator;

@ccclass('MoleData')
export class MoleData {
    @property(CCString)
    public name: String

    @property(Number)
    public score: Number = 10

    @property(Spawner)
    public spawner: Spawner = new Spawner()

    @property(Sprites)
    moveUpSprites: Sprites = new Sprites()

    public static GraphqlFields = "name,hp,point,spriteUrls";
}