
import { _decorator, Component, Node, Asset, CCFloat } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('MoleDataSpawner')
export class Spawner {

    @property([CCFloat])
    public nextSpawn: Number[] = [2]

    @property(CCFloat)
    public quantity: Number = 1
}