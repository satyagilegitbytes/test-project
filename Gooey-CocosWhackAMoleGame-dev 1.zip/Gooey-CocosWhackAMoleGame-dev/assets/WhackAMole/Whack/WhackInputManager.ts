
import { _decorator, Component, Node, systemEvent, SystemEvent, log, EventTouch, Touch, math  } from 'cc';
const { ccclass, property } = _decorator;


export const SignalWhacked = "SignalWhacked"

@ccclass('WhackInputManager')
export class WhackInputManager extends Component {
    
    onEnable() {
        systemEvent.on(SystemEvent.EventType.TOUCH_START, this.onTouchStart, this)

    }

    onDisable() {
        systemEvent.off(SystemEvent.EventType.TOUCH_START, this.onTouchStart, this)
    }

    private onTouchStart(touch: Touch, event: EventTouch) {
        this.node.emit(SignalWhacked, touch.getLocation())
    }
}