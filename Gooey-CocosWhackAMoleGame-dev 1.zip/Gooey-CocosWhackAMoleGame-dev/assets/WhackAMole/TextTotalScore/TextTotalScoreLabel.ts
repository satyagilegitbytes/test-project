
import { _decorator, Component, Node, Label } from 'cc';
import { SignalSpawnTextScore } from '../TextScore/TextScoreSpawnController';
const { ccclass, property } = _decorator;

@ccclass('TextTotalScoreLabel')
export class TextTotalScoreLabel extends Component {

    @property(Node)
    textScore: Node

    @property(Label)
    label: Label

    totalScore: number

    onLoad() {
        this.totalScore = 0
        this.updateTotalScoreLabel()
    }

    onEnable() {
        this.textScore.on(SignalSpawnTextScore, this.signalSpawnTextScore, this)
    }

    onDisable() {
        this.textScore.off(SignalSpawnTextScore, this.signalSpawnTextScore, this)
    }

    signalSpawnTextScore(score: number) {
        this.addScore(score)
    }

    addScore(addScore: number) {
        this.totalScore = Math.max(0, this.totalScore + addScore)
        this.updateTotalScoreLabel()
    }

    updateTotalScoreLabel() {
        this.label.string = this.totalScore + ""
    }

}

