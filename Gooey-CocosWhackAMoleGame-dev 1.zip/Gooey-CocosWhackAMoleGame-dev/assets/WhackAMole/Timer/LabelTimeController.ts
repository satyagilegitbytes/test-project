
import { _decorator, Component, Node, Label } from 'cc';
import { TimerManager } from './TimerManager';
const { ccclass, property } = _decorator;

@ccclass('LabelTimeController')
export class LabelTimeController extends Component {

    @property(Label)
    label: Label

    @property(TimerManager)
    timerManager: TimerManager

    start() {
        this.label.string = "n/a"
    }
    update(deltaTime: number) {
        // [4]
        this.label.string = this.timerManager.GetCounter().toFixed(0) + ""
    }
}

