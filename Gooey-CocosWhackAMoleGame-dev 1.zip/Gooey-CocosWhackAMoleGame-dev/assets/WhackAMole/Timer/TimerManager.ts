
import { _decorator, Component, Node, CCFloat } from 'cc';
const { ccclass, property } = _decorator;

export const SignalTimerStarted = "SignalTimerStarted"
export const SignalTimerTimeUp = "SignalTimerTimeUp"

@ccclass('TimerManager')
export class TimerManager extends Component {

    static _instance: TimerManager
    public static GetInstance(): TimerManager {
        return TimerManager._instance
    }

    onLoad() {
        TimerManager._instance = this
    }

    @property(CCFloat)
    durationSecond: number = 60

    counterSecond: number
    isRunning: boolean

    start() {
        this.startTimer()
    }

    startTimer() {
        this.counterSecond = this.durationSecond
        this.isRunning = true
        this.node.emit(SignalTimerStarted)
    }

    update(deltaTime: number) {
        if (this.isRunning) {
            this.counterSecond -= deltaTime

            if (this.counterSecond <= 0) {
                this.isRunning = false
                this.counterSecond = 0
                this.node.emit(SignalTimerTimeUp)
            }
        }
    }


    GetCounter(): number {
        return this.counterSecond
    }
}
